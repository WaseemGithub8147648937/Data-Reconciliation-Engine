package com.example.Data.Reconciliation.Engine.FileController;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.Data.Reconciliation.Engine.FileService.FIleService;

@RestController
public class FIleController {
	
	@Autowired
	private FIleService fileService;
	
	
	
	@RequestMapping(value = "/getDataReconciliation ", method = RequestMethod.GET)
	 public Map<String, List> fileUploadData()
	 {
		Map<String, List> mapData=fileService.matchFile(new File("X.txt"), new File("Y.txt"));
		return mapData;
		
		 
	 }

	

}
